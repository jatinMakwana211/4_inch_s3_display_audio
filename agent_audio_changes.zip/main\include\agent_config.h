#pragma once
#define AGENT_SESSION_INIT_URL "https://api.test.ai-ivrs.bonrix.in/jatin/api/init"
// Configure upload and playback independently to match the backend contract.
#define AGENT_INPUT_SAMPLE_RATE 24000
// -1 detects the active I2S slot; 0 forces left (L/R=GND), 1 forces right.
#define AGENT_MIC_SLOT -1
#define AGENT_MIC_GAIN 4
#if AGENT_MIC_SLOT < -1 || AGENT_MIC_SLOT > 1
#error "AGENT_MIC_SLOT must be -1 (auto), 0 (left), or 1 (right)"
#endif
#if AGENT_MIC_GAIN < 1 || AGENT_MIC_GAIN > 128
#error "AGENT_MIC_GAIN must be between 1 and 128"
#endif
// Assistant PCM from the 8 kHz backend must play at 8 kHz, not 24 kHz.
#define AGENT_OUTPUT_SAMPLE_RATE 8000
// Session identity matching the supplied working browser example.
// Keep these C string values free of unescaped JSON quotes/backslashes.
#define AGENT_USER_NAME "Jatin"
#define AGENT_USER_EMAIL "embeddedinnovation.bonrix@gmail.com"
#define AGENT_USER_MOBILE "8128416007"
