# ESP32-S3 five-second voice recorder

On every boot the serial monitor counts down three seconds. When `Speak now`
appears, speak into the INMP441 for five seconds. After 100 ms of microphone
startup settling, the firmware captures 80,000 samples at 16 kHz, saves
`/spiffs/recording.wav`, closes it, and reopens it for speaker playback.
Reset the board to record again.

## Wiring

| INMP441 | ESP32-S3 |
| --- | --- |
| VDD | 3.3 V |
| GND | GND |
| SCK / BCLK | GPIO19 |
| WS / LRCLK | GPIO47 |
| SD | GPIO20 |
| L/R | GND (left channel) |

**Move the microphone wires from GPIO12/13/14 before flashing this version.**
Those pins are RGB LCD data signals. GPIO19/20 are also native USB signals;
use the board's UART programming/monitor connection with this microphone wiring,
and do not connect an active native USB data cable to GPIO19/20.

MAX98357A speaker output uses BCLK GPIO46, WS GPIO45 and DIN GPIO42 with standard Philips I2S timing. Connect amplifier VIN to its supported 3.3 V or 5 V supply and share GND with the ESP32-S3. MAX98357B requires left-justified timing instead.

The microphone uses Philips I2S with two 32-bit slots (64 clocks per frame)
and captures the left slot, following the
[INMP441 datasheet](https://www.invensense.com/wp-content/uploads/2015/02/INMP441.pdf).
Signed 24-bit samples become 16-bit mono with clipping protection. Adjust
`MIC_GAIN` in `main/voice_recorder.c` (default 4) if needed.

## Storage and playback

The WAV is 160,044 bytes, including its 44-byte header. Capture uses 160 KB
PSRAM (ordinary heap fallback), then writes SPIFFS to avoid flash stalls during
recording. RX overflow or read errors abort the recording. A temporary file
is fully written and closed before replacing the previous WAV. Replacement
is not power-loss atomic. If replacement fails, the new WAV remains at
`/spiffs/recording.tmp`; the next recording removes that temporary file.
Keep space for both recordings plus filesystem overhead.

Playback reads the saved WAV and duplicates mono to both speaker channels.
It respects NVS volume (default 16/21) and audio-enabled settings. When audio
is disabled, recording still saves but playback is skipped. This path owns
its I2S channels; do not call `init_audio()` concurrently. The existing MP3
API remains available; startup no longer plays `welcome.mp3`.

## Welcome display

After recording, saving and playback, the welcome screen and touch/Wi-Fi UI
start. Audio errors are logged but do not prevent display startup. Saved Wi-Fi
reconnects after audio completes.

GPIO47 serves microphone WS during boot capture and LCD control SDA afterward.
LCD CS (GPIO39) stays high during capture. The recorder deletes its I2S channel
and holds microphone BCLK (GPIO19) low before LCD setup begins. The boot recorder
must not run concurrently with Agent Mode. Agent Mode captures after LCD startup,
keeps LCD CS (GPIO39) high and control SCLK (GPIO48) low, and reuses GPIO47 for
microphone WS. RGB refresh uses separate pins and sends no LCD control commands.
GPIO40/41 remain touch SDA/SCL.

## Agent Mode

Tap the gear beside the welcome screen's Wi-Fi icon. The Settings screen has an
Agent Mode ON/OFF switch; its value is saved in NVS. Turn it ON and tap Back to
open the conversation screen. Connect Wi-Fi using the top-right Wi-Fi icon, then
tap Back. The agent starts automatically once its secure WebSocket connects;
no wake phrase is required. Recognized speech appears
in the You card; response text appears in the Bonrix card and audio plays through
the MAX98357A. Opening settings or Wi-Fi stops streaming. Returning to the agent
screen opens a new session and starts the agent automatically. OFF returns to the
welcome screen. A saved ON setting opens the agent screen on the next boot.

The protocol follows `https://test.ai-ivrs.bonrix.in/ngemini.html`: POST userData,
websiteName, language and fileName to the session-init API, connect to its returned
`wss://` websocketUrl, and send base64 signed 16-bit little-endian mono PCM at
24 kHz in `input_audio_buffer.append`. The server performs the 24-to-16 kHz
conversion for Gemini on the original backend. The current speaker configuration
plays incoming `response.audio.delta` as 8 kHz PCM for the Jatin backend;
upload and playback rates are independently configured in `main/include/agent_config.h`.
`conversation.item.input_audio_transcription.completed` supplies user text and
`response.audio_transcript.delta` supplies assistant text. Speech-start events
preserve playback in this half-duplex client. A single `trigger.greeting` is
sent at microphone startup; assistant text and speaker output are enabled
immediately without sending another greeting.

Wake-phrase gating is disabled. After connection and microphone initialization,
the agent listens and plays the startup greeting automatically. The conversation remains
active until leaving the screen or losing the connection. Reconnects retry after
five seconds. TLS certificates are verified using the ESP-IDF certificate bundle;
SNTP must synchronize the clock first. Session identity is configured in
`main/include/agent_config.h` to match the supplied working browser example.
Other defaults are demo, English, and no context file. Transcripts use the existing ASCII font and
fixed-size recent-text cards. Hardware microphone/speaker timing, acoustic echo,
and live backend behavior require validation on the board. The microphone wiring
still uses GPIO19/20, so use UART rather than native USB.

Build and flash from an ESP-IDF terminal:

```powershell
idf.py -B build_voice build
idf.py -B build_voice -p COM6 flash monitor
```

Microphone capture runs in its own task and queues up to 32 audio blocks, so
WebSocket/TLS delays do not stop draining I2S. Queue congestion drops audio blocks
and logs a warning rather than closing the session for a DMA overflow.
Four 20 ms capture blocks are combined into each 80 ms WebSocket audio packet
(12.5 packets/sec instead of 50). Each network pass drains enough queued blocks
to fill one packet, then receives at most four chunks within a 10 ms work budget
(an individual transport read may take longer). This keeps server replies from
starving microphone uploads. Speaker buffering uses 256 KB of PSRAM; congestion
drops a complete incoming PCM chunk while preserving already buffered playback.
Playback collects 80 ms of PCM before starting or recovering from an underrun,
with a 120 ms maximum wait so short replies still play.
Microphone I2S is continuously drained, but uploads pause from the first accepted
assistant audio until `response.audio.done` or `response.done`, buffered playback drains, and the 300 ms
acoustic tail ends. Pending capture is discarded at the reply boundary to avoid
sending delayed speech or echo. TCP_NODELAY prevents delayed-ACK stalls between
WebSocket header and payload writes. Microphone uses I2S0 and speaker uses I2S1;
speaker DMA buffers clear automatically so underruns emit silence rather than
replaying stale samples. Speech-start events never flush or cancel local playback.
Wait until the reply finishes before speaking; voice interruption during playback
is disabled by this half-duplex behavior.
The screen shows `Agent speaking - please wait` while uploads are paused and
`Listening - speak to Bonrix` when microphone uploads resume. Both transitions
are also logged, so a missing completion event can be distinguished from capture failure.
Agent capture detects the active left/right microphone slot by default. Set
`AGENT_MIC_SLOT` in `main/include/agent_config.h` to 0 for left or 1 for right
to force the channel; keep L/R physically connected to GND or 3.3 V. Gain is
configured with `AGENT_MIC_GAIN` (default 4). Capture discards 100 ms of startup
data and assembles short reads into complete upload blocks. Every two seconds
of listening, `Microphone levels` reports both slot averages (before gain),
the uploaded PCM peak and clipping count. Speaking should increase these levels.
Near-zero levels while speaking indicate a capture/wiring problem. Check the
wiring table above and avoid native USB data on GPIO19/20. `Microphone upload`
reports cumulative successfully sent packets, distinguishing capture from
transport problems. Valid levels and rising packet counts without speech events
require checking recognition at the backend; packet transmission alone does
not prove that the server recognized speech.

TCP send/receive buffers are 32 KB. Wi-Fi modem sleep is disabled during the voice
session and its previous setting restored afterward. When the socket is not
ready to write, the sender waits up to ten seconds while still reading server
events. An actual failed/partial frame write still reconnects because replaying
that frame could corrupt the WebSocket stream.
`BONRIX_AGENT` logs session HTTP status, WebSocket upgrade status, the first sent
audio block, server error details, and the precise session exit reason. Session
URLs/tokens and microphone content are not logged. The display preserves the
failure reason while retrying, instead of replacing it with a generic message.
For a reconnect problem, inspect `BONRIX_AGENT: Session ended: ...` and any
preceding server/transport error. Certificate-validation messages alone indicate
successful TLS verification and do not establish why a session ended.

The firmware sends one microphone-start `trigger.greeting` on connection,
with assistant output enabled immediately. Assistant `response.audio_transcript.done` replaces partial text with
the final transcript, including responses that send no text deltas. Logs show
`Agent started automatically`, `Assistant audio received`, and `Reply finished` with
awake/audio/text/suppressed counts. `Speaker PCM playback started` reports the
actual volume and audio-enabled setting. These identify a
missing server audio payload, a decode error, and a muted speaker.

## Touch Wi-Fi setup

1. After recording/playback, tap the Wi-Fi icon at the welcome screen's top right.
2. If credentials were saved previously, the connecting screen tries that network
   for up to **15 seconds**, showing live association/DHCP stages and a countdown.
   Success opens network details. On timeout it automatically opens configuration
   and scans again. Without saved credentials, configuration opens immediately.
   The configuration screen scans visible **2.4 GHz** networks. Use the page
   arrows to see all results; duplicate access points with the same SSID/security
   are grouped. Tap the circular refresh icon to scan again. The selected network
   is highlighted, and long names are shortened with an ellipsis. ESP32-S3 cannot
   see 5 GHz-only networks.
3. Tap a network. For secured networks, enter an 8-63 character password using
   the keyboard: Shift toggles case, #+= switches to symbols, Space and Delete
   edit, and the eye icon toggles masking. Tap Done, then Connect. Open networks do not
   require a password. Connect shows the same progress screen. Wrong passwords or
   unavailable networks return to the form after the 15-second attempt.
4. After DHCP assigns an address, the connected screen displays actual SSID,
   signal strength, IPv4 address, subnet, gateway, primary/backup DNS and elapsed
   connection duration. Refresh updates signal/DNS, Configure Wi-Fi returns to
   scanning, Disconnect ends the connection, and Back returns to the welcome screen.

Connection duration is shown as elapsed time. After DHCP succeeds, the SSID, password and security
mode are committed together in the NVS `wifi_setup` namespace, key `station`.
Failed connection attempts do not replace the last working credentials. Reusing
unchanged credentials avoids rewriting flash. A storage failure is reported on
the connected screen. Passwords are never logged or copied into UI snapshots.
Saved data is loaded after recording/playback, and the device makes one automatic
15-second saved-Wi-Fi connection attempt on every boot. The welcome screen remains
visible; tapping its Wi-Fi logo shows current progress or connected details. If
the boot attempt failed, tapping the logo retries the saved network. Missing or
invalid saved data opens configuration. Disconnect keeps credentials for later use.
The 15-second deadline includes initialization, retries and DHCP; retries do not
restart it. At timeout the form appears while radio cleanup finishes, then a new
scan starts. A late IP event cannot turn a timed-out attempt into a saved success.
Back does not cancel an in-progress scan/connection, and preserves an existing
connection. The screen remains responsive while the worker scans/connects.
Controls show a pressed tint immediately and activate on release. Sliding more
than 18 pixels, sliding out of a control, or changing screens cancels that press.
Release is debounced for 16 ms, preventing repeated actions from a held finger
or a brief touch dropout. The UI polls touch every 12 ms between redraws.
Connect is enabled once a supported network and a valid-length password (when
required) are selected. The dropdown focuses the list; it does not start an
unnecessary rescan. A spinner shows ongoing network work.
Security support: open and WPA/WPA2/WPA3 Personal. Enterprise, WEP and other
unsupported security modes are listed but cannot be joined through this form.
Hidden networks/manual SSID entry and captive portal login are not implemented.
Non-ASCII SSID bytes are preserved for connecting but displayed as `?` by the
compact ASCII font. No passwords or network names from the reference artwork
are used as actual connection credentials.

Touch orientation can be adjusted with `TOUCH_SWAP_XY`, `TOUCH_MIRROR_X` and
`TOUCH_MIRROR_Y` in `main/wifi_ui.c`. These default to the unrotated board.
Regenerate the font with `powershell -File tools/generate_ui_font.ps1`.
Regenerate the curved background with `powershell -File tools/generate_wifi_background.ps1`.
The background is embedded as RGB565 so the display does not recalculate its
curves and gradients during touch events. Cards and controls are drawn in C.
Preview PNG files use sample network data only; firmware uses live scan results.
Run `python tools/test_wifi_ui.py` to test the production hit testing/keyboard/
tap tracking and generate previews. It uses the Windows TinyCC compiler at
`build/ui_host/tcc/tcc.exe`, or the path specified by the `TCC` environment
variable; TinyCC is only a desktop test dependency, not a firmware dependency.
Run `python tools/test_wifi_credentials.py` to check the production NVS record
validation, save/load round trips, unchanged-write avoidance and error handling
against a memory-backed NVS test double. These tests do not verify physical flash.

Board acceptance checks: verify all four touch corners, tap the welcome icon,
scan/page/rescan, connect to an open and WPA2 network, try a wrong password,
retry successfully, verify DHCP details, disconnect, and return to welcome.
After a successful connection, power-cycle: verify automatic use of the saved
network without tapping the screen. Turn that access point off, open the Wi-Fi
progress screen and confirm the form appears at the end of the 15-second attempt.
Try a wrong replacement password, reboot, and confirm the last
working network is still saved. Test unavailable DHCP as well as authentication
failure, and check that Back stays responsive during an attempt.
Confirm the audio recording/playback still works with the new microphone wiring.

## Build and flash

From an ESP-IDF v5.4 environment:

```sh
idf.py -B build_voice build
idf.py -B build_voice -p COM6 flash monitor
```

Full flashing writes the bundled SPIFFS image and replaces device recordings.
After SPIFFS is initialized, use `app-flash` instead of `flash` to update only
the application and retain files. Mount failure does not automatically format
SPIFFS.


