#pragma once
#define AGENT_SESSION_INIT_URL "https://api.test.ai-ivrs.bonrix.in/jatin/api/init"
// Configure upload and playback independently to match the backend contract.
#define AGENT_INPUT_SAMPLE_RATE 24000
// Assistant PCM from the 8 kHz backend must play at 8 kHz, not 24 kHz.
#define AGENT_OUTPUT_SAMPLE_RATE 8000
// Session identity matching the supplied working browser example.
// Keep these C string values free of unescaped JSON quotes/backslashes.
#define AGENT_USER_NAME "Jatin"
#define AGENT_USER_EMAIL "embeddedinnovation.bonrix@gmail.com"
#define AGENT_USER_MOBILE "8128416007"
